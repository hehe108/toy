<?php
function memcache_init()
{
                 
}
function memcache_set($aaa,$bbb)
{
	return 0;
}
function memcache_get($aaa,$bbb)
{
	return 0;
}