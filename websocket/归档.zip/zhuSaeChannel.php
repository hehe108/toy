<?php
class SaeChannel
{


function createChannel()
{
     //return "ws://channel.sinaapp.com/com/WqS5I6RhM4Ob8QlxtqWTAS3PzUL7VRTQTP9AlmMsGUZzzncQfIsWkNmWHG7YTgoZ7UxwqylEP_FlLqTFbWgVgw";
	return "ws://127.0.0.1:8080/com/WqS5I6RhM4Ob8QlxtqWTAS3PzUL7VRTQTP9AlmMsGUZzzncQfIsWkNmWHG7YTgoZ7UxwqylEP_FlLqTFbWgVgw";
}





}