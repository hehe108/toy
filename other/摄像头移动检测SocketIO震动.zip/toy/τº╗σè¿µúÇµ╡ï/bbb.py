# -*- coding:utf-8 -*-
from PIL import ImageGrab
import cv2
import numpy as np
import datetime
import time


def fffffff():
	loginFile = open(u"C:\\Users\\hello\\Desktop\\新建文件夹\\toy\\chat-Vibrate\\public\\hello.txt", "w")  
	loginFile.write(str(datetime.datetime.now()))
	loginFile.close()







firstFrame = None

while True:
	time.sleep(2)


	im = ImageGrab.grab()
	region = (0,200,610,560)




	cropImg = im.crop(region)
	arr = np.asarray(cropImg)
	gray = cv2.cvtColor(arr, cv2.COLOR_BGR2GRAY)
	gray = cv2.GaussianBlur(gray, (3, 3), 0)
	if firstFrame is None:
		firstFrame = gray
		continue

	frameDelta = cv2.absdiff(firstFrame, gray)
	firstFrame=gray     
	thresh = cv2.threshold(frameDelta, 25, 255, cv2.THRESH_BINARY)[1]
	thresh = cv2.dilate(thresh, None, iterations=2)
	(_,cnts ,_) = cv2.findContours(thresh.copy(), cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
	print "--------------------"
	needSave=0
	for c  in  cnts:
		print "..."
		dddd=cv2.contourArea(c)
		print dddd
		if dddd<200:
			continue
		#画出大于200 的轮廓
		(x, y, w, h) = cv2.boundingRect(c)
		if  x<280 or x>480  or  y<150 or y>260 :	
			continue



		cv2.rectangle(arr, (x, y), (x + w, y + h), (0, 255, 0), 2)
		needSave=1
	if needSave==1:
		cv2.imwrite(str(datetime.datetime.now()).replace(":", "")+'.png',arr)
		fffffff()

