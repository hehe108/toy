# -*- coding:utf-8 -*-
from PIL import ImageGrab
import cv2
import numpy as np
import datetime
import time




im = ImageGrab.grab()
#region = (0,200,610,560)





arr = np.asarray(im)
cv2.rectangle(arr, (0, 200), (610, 560), (0, 255, 0), 2)

#x<280 or x>480           y<150 or y>260 

cv2.rectangle(arr, (0+200,200+ 150), (0+480,200+ 260), (0, 255, 0), 2)

cv2.imwrite('save.png',arr)

