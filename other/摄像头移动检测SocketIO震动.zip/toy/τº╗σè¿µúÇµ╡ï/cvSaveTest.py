# -*- coding:utf-8 -*-
from PIL import ImageGrab
import cv2
import numpy as np
import datetime
import time






arr = np.array([1, 2, 3, 4])
cv2.imwrite(str(datetime.datetime.now()).replace(":", "")+'.png',arr)

