# DengtaChromeExtension

## 仅供模拟考试学习交流使用,请勿用于非法用途

历史版本 
[二三月](https://github.com/tyrad/DengtaChromeExtension/tree/二三月份)
[四月](https://github.com/tyrad/DengtaChromeExtension/tree/四月题)
[五月题库](https://github.com/tyrad/DengtaChromeExtension/tree/五月题库)


使用方法见: [用法](https://github.com/tyrad/DengtaChromeExtension/issues/1)
