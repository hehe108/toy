$(function() {
	
	//alert("灯塔插件初始化完成~");
	 
console.log("替换https");
fff();

setInterval(fff, 5000);

});




function fff()
{
  
	console.log("fff");
　$('a').each(function(){
　　　　//let Ahref = $(this).html() + "#article";
	   var ddddd=$(this).attr("href");
	   //console.log(ddddd);

		if(ddddd!=undefined)
		{

		   if(ddddd.indexOf("baidu.com")>=0||ddddd.indexOf("cnblogs.com")>=0||ddddd.indexOf("36kr.com")>=0)
		   {
			   	//console.log(ddddd);

				   	if(ddddd.indexOf("https")<0&&ddddd.indexOf("http")>=0)
				   	{
				   		//console.log("11111111");
				   		var  xxxxxxx=ddddd.replace("http","https");
				   		$(this).attr("href",xxxxxxx);
				   	}		   		
			   	

	　　　　		
			}
		}
　　});


}
